// Текущие время, дата, день недели

window.onload = function(){
    window.setInterval(function(){
        var date = new Date();

        var hours = date.getHours();
        var minutes = date.getMinutes();
        var seconds = date.getSeconds();

        var month = date.getMonth() + 1;
        var day = date.getDate();
        var year = date.getFullYear();

        var weekday = date.getDay();

        if(hours < 10) hours = "0" + hours;
        if(minutes < 10) minutes = "0" + minutes;
        if(seconds < 10) seconds = "0" + seconds;

        if(month < 10) month = "0" + month;
        if(day < 10) day = "0" + day;
        if(year < 10) year = "0" + year;

        if(weekday == 0) weekday = "Воскресенье";
        if(weekday == 1) weekday = "Понедельник";
        if(weekday == 2) weekday = "Вторник";
        if(weekday == 3) weekday = "Среда";
        if(weekday == 4) weekday = "Четверг";
        if(weekday == 5) weekday = "Пятница";
        if(weekday == 6) weekday = "Суббота";

        var clock = hours + ":" + minutes + ":" + seconds;
        var clockdate = day + "." + month + "." + year;
        var weekd = weekday;
        document.getElementById("clock").innerHTML = clock;
        document.getElementById("date").innerHTML = clockdate;
        document.getElementById("weekday").innerHTML = weekd;
    }, 0)
};